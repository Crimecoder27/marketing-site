export interface Product {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  affiliateLink: string;
  category: string;
  platform: "Amazon" | "Flipkart" | "Myntra" | "Other";
  price?: string;
  originalPrice?: string;
  badge?: string;
  createdAt: Date | string;
  updatedAt: Date | string;
}

export interface FeedbackMessage {
  id: string;
  name: string;
  email: string;
  message: string;
  createdAt: Date | string;
  isRead: boolean;
}

export interface AdminUser {
  uid: string;
  email: string;
  role: "admin";
}

export interface ProductFormData {
  title: string;
  description: string;
  imageUrl: string;
  affiliateLink: string;
  category: string;
  platform: "Amazon" | "Flipkart" | "Myntra" | "Other";
  price?: string;
  originalPrice?: string;
  badge?: string;
}

export interface FeedbackFormData {
  name: string;
  email: string;
  message: string;
}
