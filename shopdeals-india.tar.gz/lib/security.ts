import { z } from "zod";

// Sanitize string: remove HTML tags & dangerous chars
export function sanitizeString(input: string): string {
  return input
    .replace(/<[^>]*>/g, "")
    .replace(/[<>"'`]/g, "")
    .trim()
    .slice(0, 2000);
}

// Validate affiliate URL — allow only http/https
export function isValidAffiliateUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    return ["http:", "https:"].includes(parsed.protocol);
  } catch {
    return false;
  }
}

// Zod schemas
export const productSchema = z.object({
  title: z.string().min(2).max(200).transform(sanitizeString),
  description: z.string().min(5).max(1000).transform(sanitizeString),
  imageUrl: z.string().url("Must be a valid image URL"),
  affiliateLink: z
    .string()
    .url("Must be a valid URL")
    .refine(isValidAffiliateUrl, "Only http/https URLs allowed"),
  category: z.string().min(1).max(100).transform(sanitizeString),
  platform: z.enum(["Amazon", "Flipkart", "Myntra", "Other"]),
  price: z.string().max(50).optional().transform((v) => v ? sanitizeString(v) : v),
  originalPrice: z.string().max(50).optional().transform((v) => v ? sanitizeString(v) : v),
  badge: z.string().max(50).optional().transform((v) => v ? sanitizeString(v) : v),
});

export const feedbackSchema = z.object({
  name: z
    .string()
    .min(2, "Name must be at least 2 characters")
    .max(100)
    .transform(sanitizeString),
  email: z.string().email("Invalid email address").max(200),
  message: z
    .string()
    .min(10, "Message must be at least 10 characters")
    .max(2000)
    .transform(sanitizeString),
});

// Rate limiting store (in-memory for edge/serverless)
const rateLimitStore = new Map<string, { count: number; resetAt: number }>();

export function checkRateLimit(
  ip: string,
  max = 10,
  windowMs = 60_000
): boolean {
  const now = Date.now();
  const entry = rateLimitStore.get(ip);

  if (!entry || now > entry.resetAt) {
    rateLimitStore.set(ip, { count: 1, resetAt: now + windowMs });
    return true; // allowed
  }

  if (entry.count >= max) return false; // blocked

  entry.count++;
  return true;
}
