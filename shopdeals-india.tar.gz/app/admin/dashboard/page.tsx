"use client";
import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import toast from "react-hot-toast";
import { useAuth } from "@/lib/auth-context";
import { getProducts, addProduct, updateProduct, deleteProduct, getFeedbackMessages, markFeedbackRead } from "@/lib/db";
import ProductFormModal from "@/components/admin/ProductFormModal";
import type { Product, FeedbackMessage, ProductFormData } from "@/types";
import {
  LogOut, Plus, Edit2, Trash2, Package, MessageSquare,
  ShoppingBag, RefreshCw, Eye, CheckCircle
} from "lucide-react";

type Tab = "products" | "feedback";

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const router = useRouter();

  const [tab, setTab] = useState<Tab>("products");
  const [products, setProducts] = useState<Product[]>([]);
  const [feedback, setFeedback] = useState<FeedbackMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [p, f] = await Promise.all([getProducts(), getFeedbackMessages()]);
      setProducts(p);
      setFeedback(f);
    } catch {
      toast.error("Failed to load data");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleLogout = async () => {
    await logout();
    router.push("/admin/login");
  };

  const handleAddOrEdit = async (data: ProductFormData) => {
    setSubmitting(true);
    try {
      if (editProduct) {
        await updateProduct(editProduct.id, data);
        toast.success("Product updated!");
      } else {
        await addProduct(data);
        toast.success("Product added!");
      }
      setShowModal(false);
      setEditProduct(null);
      await loadData();
    } catch {
      toast.error("Failed to save product");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteProduct(id);
      toast.success("Product deleted");
      setDeleteConfirm(null);
      await loadData();
    } catch {
      toast.error("Delete failed");
    }
  };

  const handleMarkRead = async (id: string) => {
    try {
      await markFeedbackRead(id);
      setFeedback((prev) => prev.map((f) => f.id === id ? { ...f, isRead: true } : f));
    } catch {
      toast.error("Failed to mark as read");
    }
  };

  const unreadCount = feedback.filter((f) => !f.isRead).length;

  return (
    <div className="min-h-screen relative z-10">
      {/* Top bar */}
      <header className="glass sticky top-0 z-40 px-4 sm:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl btn-primary flex items-center justify-center">
            <ShoppingBag size={16} />
          </div>
          <div>
            <span className="font-display font-bold gradient-text">ShopDeals</span>
            <span className="text-xs ml-2" style={{ color: "var(--text-muted)" }}>Admin</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className="hidden sm:block text-xs" style={{ color: "var(--text-muted)" }}>
            {user?.email}
          </span>
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs glass transition-colors hover:border-red-500/30"
            style={{ color: "var(--text-secondary)" }}
          >
            <LogOut size={13} />
            Logout
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Total Products", value: products.length, icon: Package, color: "var(--teal)" },
            { label: "Unread Messages", value: unreadCount, icon: MessageSquare, color: "var(--coral)" },
            { label: "Total Feedback", value: feedback.length, icon: Eye, color: "var(--sage)" },
            { label: "Platforms", value: [...new Set(products.map((p) => p.platform))].length, icon: ShoppingBag, color: "var(--teal)" },
          ].map((stat, i) => {
            const Icon = stat.icon;
            return (
              <div key={i} className="glass rounded-2xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${stat.color}18`, border: `1px solid ${stat.color}30` }}>
                  <Icon size={18} style={{ color: stat.color }} />
                </div>
                <div>
                  <p className="text-xl font-bold" style={{ color: "var(--text-primary)" }}>{stat.value}</p>
                  <p className="text-xs" style={{ color: "var(--text-muted)" }}>{stat.label}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Tabs */}
        <div className="glass rounded-2xl p-1 inline-flex gap-1 mb-6">
          {(["products", "feedback"] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-5 py-2 rounded-xl text-sm font-medium capitalize transition-all ${tab === t ? "btn-primary" : ""}`}
              style={tab !== t ? { color: "var(--text-secondary)" } : {}}
            >
              {t}
              {t === "feedback" && unreadCount > 0 && (
                <span className="ml-2 px-1.5 py-0.5 rounded-full text-xs" style={{ background: "var(--coral)", color: "#1a0800" }}>
                  {unreadCount}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Products tab */}
        {tab === "products" && (
          <div>
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-semibold" style={{ color: "var(--text-primary)" }}>
                Products ({products.length})
              </h2>
              <div className="flex gap-2">
                <button onClick={loadData} className="p-2.5 glass rounded-xl" style={{ color: "var(--text-muted)" }}>
                  <RefreshCw size={15} />
                </button>
                <button
                  onClick={() => { setEditProduct(null); setShowModal(true); }}
                  className="btn-primary flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm"
                >
                  <Plus size={15} />
                  Add Product
                </button>
              </div>
            </div>

            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="glass rounded-2xl overflow-hidden">
                    <div className="skeleton w-full h-40" />
                    <div className="p-4 flex flex-col gap-2">
                      <div className="skeleton h-4 w-3/4 rounded" />
                      <div className="skeleton h-3 w-1/2 rounded" />
                    </div>
                  </div>
                ))}
              </div>
            ) : products.length === 0 ? (
              <div className="glass rounded-2xl py-16 text-center">
                <Package size={48} className="mx-auto mb-4" style={{ color: "var(--text-muted)" }} />
                <p style={{ color: "var(--text-secondary)" }}>No products yet. Add your first one!</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {products.map((p) => (
                  <div key={p.id} className="glass rounded-2xl overflow-hidden group">
                    <div className="relative h-40">
                      <Image
                        src={p.imageUrl || "/placeholder.png"}
                        alt={p.title}
                        fill
                        sizes="33vw"
                        className="object-cover"
                        onError={(e) => { (e.target as HTMLImageElement).src = "/placeholder.png"; }}
                      />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                        <button
                          onClick={() => { setEditProduct(p); setShowModal(true); }}
                          className="w-9 h-9 btn-primary rounded-xl flex items-center justify-center"
                        >
                          <Edit2 size={14} />
                        </button>
                        <button
                          onClick={() => setDeleteConfirm(p.id)}
                          className="w-9 h-9 rounded-xl flex items-center justify-center"
                          style={{ background: "rgba(219,163,128,0.2)", color: "var(--coral)", border: "1px solid rgba(219,163,128,0.3)" }}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="text-sm font-medium line-clamp-1 mb-1" style={{ color: "var(--text-primary)" }}>{p.title}</h3>
                      <div className="flex items-center justify-between">
                        <span className={`text-xs px-2 py-0.5 rounded-full badge-${p.platform.toLowerCase()}`}>{p.platform}</span>
                        {p.price && <span className="text-sm font-bold gradient-text">₹{p.price}</span>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Feedback tab */}
        {tab === "feedback" && (
          <div>
            <h2 className="font-semibold mb-5" style={{ color: "var(--text-primary)" }}>
              Messages ({feedback.length})
            </h2>
            {feedback.length === 0 ? (
              <div className="glass rounded-2xl py-16 text-center">
                <MessageSquare size={48} className="mx-auto mb-4" style={{ color: "var(--text-muted)" }} />
                <p style={{ color: "var(--text-secondary)" }}>No messages yet.</p>
              </div>
            ) : (
              <div className="flex flex-col gap-3">
                {feedback.map((f) => (
                  <div key={f.id} className={`glass rounded-2xl p-5 ${!f.isRead ? "border-l-2" : ""}`} style={!f.isRead ? { borderLeftColor: "var(--teal)" } : {}}>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className="font-medium text-sm" style={{ color: "var(--text-primary)" }}>{f.name}</span>
                          <span className="text-xs" style={{ color: "var(--text-muted)" }}>{f.email}</span>
                          {!f.isRead && (
                            <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "rgba(115,209,211,0.15)", color: "var(--teal)" }}>New</span>
                          )}
                        </div>
                        <p className="text-sm leading-relaxed" style={{ color: "var(--text-secondary)" }}>{f.message}</p>
                        <p className="text-xs mt-2" style={{ color: "var(--text-muted)" }}>
                          {typeof f.createdAt === "string" ? new Date(f.createdAt).toLocaleString("en-IN") : ""}
                        </p>
                      </div>
                      {!f.isRead && (
                        <button
                          onClick={() => handleMarkRead(f.id)}
                          className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs glass"
                          style={{ color: "var(--teal)" }}
                        >
                          <CheckCircle size={12} />
                          Mark read
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Product modal */}
      {showModal && (
        <ProductFormModal
          onClose={() => { setShowModal(false); setEditProduct(null); }}
          onSubmit={handleAddOrEdit}
          editProduct={editProduct}
          submitting={submitting}
        />
      )}

      {/* Delete confirm */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)" }}>
          <div className="glass-strong rounded-2xl p-8 max-w-sm w-full text-center">
            <Trash2 size={36} className="mx-auto mb-4" style={{ color: "var(--coral)" }} />
            <h3 className="font-semibold text-lg mb-2" style={{ color: "var(--text-primary)" }}>Delete Product?</h3>
            <p className="text-sm mb-6" style={{ color: "var(--text-secondary)" }}>This action cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-2.5 rounded-xl text-sm glass" style={{ color: "var(--text-secondary)" }}>
                Cancel
              </button>
              <button onClick={() => handleDelete(deleteConfirm)} className="flex-1 py-2.5 rounded-xl text-sm btn-coral">
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
