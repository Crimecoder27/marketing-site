"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/lib/auth-context";
import { ShoppingBag, Lock, Mail, Eye, EyeOff, AlertCircle } from "lucide-react";

const loginSchema = z.object({
  email: z.string().email("Invalid email"),
  password: z.string().min(6, "Password too short"),
});
type LoginForm = z.infer<typeof loginSchema>;

// Brute-force protection: track failed attempts
let failedAttempts = 0;
let lockoutUntil = 0;

export default function AdminLoginPage() {
  const { login, user, loading } = useAuth();
  const router = useRouter();
  const [showPw, setShowPw] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [locked, setLocked] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
  });

  useEffect(() => {
    if (!loading && user) router.replace("/admin/dashboard");
  }, [user, loading, router]);

  const onSubmit = async (data: LoginForm) => {
    if (Date.now() < lockoutUntil) {
      setLocked(true);
      setError("Too many failed attempts. Try again in 2 minutes.");
      return;
    }

    setSubmitting(true);
    setError("");
    try {
      await login(data.email, data.password);
      failedAttempts = 0;
      router.push("/admin/dashboard");
    } catch {
      failedAttempts++;
      if (failedAttempts >= 5) {
        lockoutUntil = Date.now() + 2 * 60 * 1000;
        setLocked(true);
        setError("Too many failed attempts. Locked for 2 minutes.");
      } else {
        setError(`Invalid credentials. ${5 - failedAttempts} attempts remaining.`);
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-[var(--teal)] border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      {/* Orb */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(115,209,211,0.08) 0%, transparent 70%)", filter: "blur(60px)" }} />

      <div className="relative w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl btn-primary flex items-center justify-center mx-auto mb-4">
            <ShoppingBag size={24} />
          </div>
          <h1 className="font-display font-bold text-2xl gradient-text">Admin Panel</h1>
          <p className="text-sm mt-1" style={{ color: "var(--text-muted)" }}>ShopDeals India</p>
        </div>

        <div className="glass-strong rounded-3xl p-8">
          <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-5" noValidate>
            {/* Email */}
            <div>
              <label className="block text-xs font-medium mb-2" style={{ color: "var(--text-secondary)" }}>
                Email
              </label>
              <div className="relative">
                <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: "var(--text-muted)" }} />
                <input
                  {...register("email")}
                  type="email"
                  autoComplete="email"
                  placeholder="admin@example.com"
                  className="input-glass w-full pl-10 pr-4 py-3 rounded-xl text-sm"
                />
              </div>
              {errors.email && <p className="text-xs mt-1" style={{ color: "var(--coral)" }}>{errors.email.message}</p>}
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-medium mb-2" style={{ color: "var(--text-secondary)" }}>
                Password
              </label>
              <div className="relative">
                <Lock size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: "var(--text-muted)" }} />
                <input
                  {...register("password")}
                  type={showPw ? "text" : "password"}
                  autoComplete="current-password"
                  placeholder="••••••••"
                  className="input-glass w-full pl-10 pr-10 py-3 rounded-xl text-sm"
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2"
                  style={{ color: "var(--text-muted)" }}
                >
                  {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
              {errors.password && <p className="text-xs mt-1" style={{ color: "var(--coral)" }}>{errors.password.message}</p>}
            </div>

            {/* Error */}
            {error && (
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs" style={{ background: "rgba(219,163,128,0.1)", border: "1px solid rgba(219,163,128,0.3)", color: "var(--coral)" }}>
                <AlertCircle size={13} />
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={submitting || locked}
              className="btn-primary py-3.5 rounded-xl text-sm flex items-center justify-center gap-2 mt-1 disabled:opacity-50"
            >
              {submitting ? (
                <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
              ) : (
                <Lock size={14} />
              )}
              {submitting ? "Signing in..." : "Sign In"}
            </button>
          </form>
        </div>

        <p className="text-center text-xs mt-4" style={{ color: "var(--text-muted)" }}>
          Protected admin area. Unauthorised access is prohibited.
        </p>
      </div>
    </div>
  );
}
