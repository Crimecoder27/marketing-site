import { NextRequest, NextResponse } from "next/server";
import { submitFeedback, getFeedbackMessages } from "@/lib/db";
import { feedbackSchema, checkRateLimit } from "@/lib/security";

// POST /api/feedback - Public (with rate limiting)
export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for") ?? "unknown";

  // Rate limit: max 3 feedback submissions per minute per IP
  if (!checkRateLimit(`feedback:${ip}`, 3, 60_000)) {
    return NextResponse.json(
      { error: "Too many requests. Please wait before submitting again." },
      { status: 429 }
    );
  }

  try {
    const body = await req.json();
    const parsed = feedbackSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid data", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const id = await submitFeedback(parsed.data);
    return NextResponse.json({ id }, { status: 201 });
  } catch (error) {
    console.error("[POST /api/feedback]", error);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// GET /api/feedback - Admin only
export async function GET(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const messages = await getFeedbackMessages();
    return NextResponse.json({ messages });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
