import { NextRequest, NextResponse } from "next/server";
import { getProducts, addProduct } from "@/lib/db";
import { productSchema, checkRateLimit } from "@/lib/security";
import { auth } from "@/lib/firebase";

// GET /api/products - Public
export async function GET() {
  try {
    const products = await getProducts();
    return NextResponse.json({ products }, {
      headers: {
        "Cache-Control": "s-maxage=60, stale-while-revalidate=120",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch (error) {
    console.error("[GET /api/products]", error);
    return NextResponse.json({ error: "Failed to fetch products" }, { status: 500 });
  }
}

// POST /api/products - Admin only (client calls this with Firebase ID token)
export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for") ?? "unknown";

  // Rate limit
  if (!checkRateLimit(ip, 20, 60_000)) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }

  // Verify auth token
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const parsed = productSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid data", details: parsed.error.flatten() }, { status: 400 });
    }
    const id = await addProduct(parsed.data);
    return NextResponse.json({ id }, { status: 201 });
  } catch (error) {
    console.error("[POST /api/products]", error);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
