"use client";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import toast from "react-hot-toast";
import { Send, MessageSquare } from "lucide-react";
import { feedbackSchema } from "@/lib/security";
import type { FeedbackFormData } from "@/types";

export default function ContactForm() {
  const [submitting, setSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FeedbackFormData>({
    resolver: zodResolver(feedbackSchema),
  });

  const onSubmit = async (data: FeedbackFormData) => {
    setSubmitting(true);
    try {
      const res = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed");
      toast.success("Message sent! We'll get back to you soon.");
      reset();
    } catch {
      toast.error("Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="contact" className="relative py-20 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 glass rounded-full px-4 py-2 mb-6">
            <MessageSquare size={14} style={{ color: "var(--teal)" }} />
            <span className="text-xs" style={{ color: "var(--text-secondary)" }}>Get in touch</span>
          </div>
          <h2 className="font-display font-bold text-3xl md:text-4xl mb-3">
            <span className="gradient-text">Have a Query?</span>
          </h2>
          <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
            Ask us about any product, suggest a deal, or just say hello.
          </p>
        </div>

        <div className="glass-strong rounded-3xl p-8">
          <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-5" noValidate>
            {/* Name */}
            <div>
              <label className="block text-xs font-medium mb-2" style={{ color: "var(--text-secondary)" }}>
                Your Name
              </label>
              <input
                {...register("name")}
                type="text"
                autoComplete="name"
                placeholder="Rahul Sharma"
                className="input-glass w-full px-4 py-3 rounded-xl text-sm"
              />
              {errors.name && (
                <p className="text-xs mt-1.5" style={{ color: "var(--coral)" }}>{errors.name.message}</p>
              )}
            </div>

            {/* Email */}
            <div>
              <label className="block text-xs font-medium mb-2" style={{ color: "var(--text-secondary)" }}>
                Email Address
              </label>
              <input
                {...register("email")}
                type="email"
                autoComplete="email"
                placeholder="rahul@example.com"
                className="input-glass w-full px-4 py-3 rounded-xl text-sm"
              />
              {errors.email && (
                <p className="text-xs mt-1.5" style={{ color: "var(--coral)" }}>{errors.email.message}</p>
              )}
            </div>

            {/* Message */}
            <div>
              <label className="block text-xs font-medium mb-2" style={{ color: "var(--text-secondary)" }}>
                Message
              </label>
              <textarea
                {...register("message")}
                rows={4}
                placeholder="Tell us what you're looking for..."
                className="input-glass w-full px-4 py-3 rounded-xl text-sm resize-none"
              />
              {errors.message && (
                <p className="text-xs mt-1.5" style={{ color: "var(--coral)" }}>{errors.message.message}</p>
              )}
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="btn-primary flex items-center justify-center gap-2 py-3.5 rounded-xl text-sm disabled:opacity-60"
            >
              {submitting ? (
                <>
                  <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  Send Message
                  <Send size={14} />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
