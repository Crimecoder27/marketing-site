"use client";
import { useState, useEffect } from "react";
import { ChevronUp } from "lucide-react";

export default function ScrollToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handler = () => setVisible(window.scrollY > 400);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  if (!visible) return null;

  return (
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className="fixed bottom-6 right-6 z-50 w-11 h-11 rounded-full btn-primary flex items-center justify-center shadow-lg"
      aria-label="Scroll to top"
      style={{ boxShadow: "0 4px 24px rgba(115,209,211,0.3)" }}
    >
      <ChevronUp size={18} />
    </button>
  );
}
