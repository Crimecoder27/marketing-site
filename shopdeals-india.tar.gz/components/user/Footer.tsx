import { ShoppingBag } from "lucide-react";

export default function Footer() {
  return (
    <footer className="relative border-t py-10 px-4" style={{ borderColor: "var(--glass-border)" }}>
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Brand */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl btn-primary flex items-center justify-center">
            <ShoppingBag size={15} />
          </div>
          <span className="font-display font-bold gradient-text">ShopDeals India</span>
        </div>

        {/* Links */}
        <div className="flex items-center gap-6 text-xs" style={{ color: "var(--text-muted)" }}>
          <a href="#products" className="hover:text-[var(--teal)] transition-colors">Products</a>
          <a href="#how-it-works" className="hover:text-[var(--teal)] transition-colors">How It Works</a>
          <a href="#contact" className="hover:text-[var(--teal)] transition-colors">Contact</a>
        </div>

        {/* Copyright */}
        <p className="text-xs text-center" style={{ color: "var(--text-muted)" }}>
          © {new Date().getFullYear()} ShopDeals India. Affiliate links may earn us a commission.
        </p>
      </div>
    </footer>
  );
}
