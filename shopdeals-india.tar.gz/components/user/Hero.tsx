"use client";
import { useState } from "react";
import { Search, Sparkles, ArrowDown } from "lucide-react";

interface HeroProps {
  onSearch: (q: string) => void;
}

export default function Hero({ onSearch }: HeroProps) {
  const [query, setQuery] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(query);
    document.getElementById("products")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center text-center px-4 pt-24 pb-16 overflow-hidden">
      {/* Decorative orbs */}
      <div
        className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(115,209,211,0.12) 0%, transparent 70%)", filter: "blur(40px)" }}
      />
      <div
        className="absolute bottom-1/3 right-1/4 w-48 h-48 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(219,163,128,0.10) 0%, transparent 70%)", filter: "blur(30px)" }}
      />

      {/* Badge */}
      <div className="relative glass rounded-full px-4 py-2 mb-8 inline-flex items-center gap-2 floating">
        <Sparkles size={14} style={{ color: "var(--coral)" }} />
        <span className="text-xs font-medium" style={{ color: "var(--text-secondary)" }}>
          Handpicked deals from top platforms
        </span>
      </div>

      {/* Headline */}
      <h1 className="relative font-display font-bold mb-6 leading-tight" style={{ fontSize: "clamp(2.4rem,6vw,5rem)" }}>
        <span className="gradient-text">Discover Premium</span>
        <br />
        <span style={{ color: "var(--text-primary)" }}>Affiliate Deals</span>
      </h1>

      <p className="relative max-w-xl mx-auto text-base mb-10 leading-relaxed" style={{ color: "var(--text-secondary)" }}>
        Curated products from Amazon, Flipkart, Myntra &amp; more — handpicked for the best value in India.
      </p>

      {/* Search */}
      <form onSubmit={handleSubmit} className="relative w-full max-w-lg mx-auto">
        <div className="glass-strong rounded-2xl flex items-center gap-3 px-4 py-3">
          <Search size={18} style={{ color: "var(--text-muted)" }} />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products, categories..."
            className="flex-1 bg-transparent text-sm outline-none"
            style={{ color: "var(--text-primary)" }}
          />
          <button type="submit" className="btn-primary px-5 py-2 rounded-xl text-sm">
            Search
          </button>
        </div>
      </form>

      {/* Scroll CTA */}
      <a
        href="#products"
        className="relative mt-16 flex flex-col items-center gap-2 opacity-60 hover:opacity-100 transition-opacity"
        style={{ color: "var(--text-muted)" }}
      >
        <span className="text-xs tracking-widest uppercase">Explore</span>
        <ArrowDown size={16} className="floating" />
      </a>
    </section>
  );
}
