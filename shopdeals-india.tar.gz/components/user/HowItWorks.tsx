import { Search, MousePointerClick, BadgePercent, Wallet } from "lucide-react";

const steps = [
  {
    icon: Search,
    title: "Browse Products",
    desc: "Explore our curated collection of handpicked deals across categories.",
    color: "var(--teal)",
  },
  {
    icon: MousePointerClick,
    title: "Click a Deal",
    desc: "Tap 'View Deal' to head directly to the product on Amazon, Flipkart, or Myntra.",
    color: "var(--sage)",
  },
  {
    icon: BadgePercent,
    title: "Get the Best Price",
    desc: "Shop at the best available price through our tracked affiliate link.",
    color: "var(--coral)",
  },
  {
    icon: Wallet,
    title: "Save Every Time",
    desc: "We earn a small commission — at zero extra cost to you. Win-win!",
    color: "var(--teal)",
  },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="relative py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <h2 className="font-display font-bold text-3xl md:text-4xl mb-3">
            <span style={{ color: "var(--text-primary)" }}>How It </span>
            <span className="gradient-text">Works</span>
          </h2>
          <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
            Simple, transparent, free for you
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {steps.map((step, i) => {
            const Icon = step.icon;
            return (
              <div key={i} className="glass rounded-2xl p-6 flex flex-col gap-4 group transition-all duration-300 hover:-translate-y-1">
                {/* Step number */}
                <div className="flex items-center justify-between">
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center"
                    style={{ background: `${step.color}18`, border: `1px solid ${step.color}30` }}
                  >
                    <Icon size={20} style={{ color: step.color }} />
                  </div>
                  <span
                    className="font-display font-bold text-4xl opacity-10"
                    style={{ color: step.color }}
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                </div>
                <h3 className="font-semibold text-base" style={{ color: "var(--text-primary)" }}>
                  {step.title}
                </h3>
                <p className="text-sm leading-relaxed" style={{ color: "var(--text-secondary)" }}>
                  {step.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
