"use client";
import Image from "next/image";
import { ExternalLink, Tag } from "lucide-react";
import type { Product } from "@/types";

interface ProductCardProps {
  product: Product;
}

const platformClass: Record<string, string> = {
  Amazon: "badge-amazon",
  Flipkart: "badge-flipkart",
  Myntra: "badge-myntra",
  Other: "badge-other",
};

export default function ProductCard({ product }: ProductCardProps) {
  return (
    <div
      className="glass rounded-2xl overflow-hidden group transition-all duration-300 flex flex-col"
      style={{ transition: "transform 0.3s, box-shadow 0.3s" }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLElement).style.transform = "translateY(-6px)";
        (e.currentTarget as HTMLElement).style.boxShadow = "0 20px 60px rgba(0,0,0,0.5), 0 0 40px rgba(115,209,211,0.08)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
        (e.currentTarget as HTMLElement).style.boxShadow = "var(--glass-shadow)";
      }}
    >
      {/* Image */}
      <div className="relative w-full h-52 overflow-hidden bg-black/20">
        <Image
          src={product.imageUrl || "/placeholder.png"}
          alt={product.title}
          fill
          sizes="(max-width:768px) 100vw, 33vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
          onError={(e) => {
            (e.target as HTMLImageElement).src = "/placeholder.png";
          }}
        />
        {/* Badge */}
        <div className="absolute top-3 left-3 flex gap-2 flex-wrap">
          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${platformClass[product.platform] || "badge-other"}`}>
            {product.platform}
          </span>
          {product.badge && (
            <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ background: "rgba(219,163,128,0.2)", color: "var(--coral)", border: "1px solid rgba(219,163,128,0.3)" }}>
              {product.badge}
            </span>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-4 flex flex-col flex-1 gap-3">
        {/* Category */}
        <div className="flex items-center gap-1.5">
          <Tag size={11} style={{ color: "var(--text-muted)" }} />
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>{product.category}</span>
        </div>

        {/* Title */}
        <h3
          className="font-semibold text-sm leading-snug line-clamp-2"
          style={{ color: "var(--text-primary)" }}
        >
          {product.title}
        </h3>

        {/* Description */}
        <p className="text-xs leading-relaxed line-clamp-2 flex-1" style={{ color: "var(--text-secondary)" }}>
          {product.description}
        </p>

        {/* Price */}
        {(product.price || product.originalPrice) && (
          <div className="flex items-baseline gap-2">
            {product.price && (
              <span className="font-bold text-base gradient-text">₹{product.price}</span>
            )}
            {product.originalPrice && (
              <span className="text-xs line-through" style={{ color: "var(--text-muted)" }}>
                ₹{product.originalPrice}
              </span>
            )}
          </div>
        )}

        {/* CTA */}
        <a
          href={product.affiliateLink}
          target="_blank"
          rel="noopener noreferrer nofollow"
          className="btn-primary w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm mt-1"
        >
          View Deal
          <ExternalLink size={13} />
        </a>
      </div>
    </div>
  );
}
