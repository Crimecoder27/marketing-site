"use client";
import { useState, useEffect, useMemo } from "react";
import { Search, Package } from "lucide-react";
import ProductCard from "./ProductCard";
import type { Product } from "@/types";

interface ProductGridProps {
  searchQuery: string;
}

function SkeletonCard() {
  return (
    <div className="glass rounded-2xl overflow-hidden">
      <div className="skeleton w-full h-52" />
      <div className="p-4 flex flex-col gap-3">
        <div className="skeleton h-3 w-20 rounded" />
        <div className="skeleton h-4 w-full rounded" />
        <div className="skeleton h-4 w-3/4 rounded" />
        <div className="skeleton h-3 w-full rounded" />
        <div className="skeleton h-10 w-full rounded-xl mt-2" />
      </div>
    </div>
  );
}

export default function ProductGrid({ searchQuery }: ProductGridProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [localSearch, setLocalSearch] = useState("");

  useEffect(() => {
    setLocalSearch(searchQuery);
  }, [searchQuery]);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/products");
        const data = await res.json();
        setProducts(data.products || []);
      } catch {
        setProducts([]);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const filtered = useMemo(() => {
    const q = localSearch.toLowerCase().trim();
    if (!q) return products;
    return products.filter(
      (p) =>
        p.title.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.platform.toLowerCase().includes(q)
    );
  }, [products, localSearch]);

  return (
    <section id="products" className="relative py-20 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-12">
          <h2 className="font-display font-bold text-3xl md:text-4xl mb-3">
            <span className="gradient-text">Featured</span>{" "}
            <span style={{ color: "var(--text-primary)" }}>Products</span>
          </h2>
          <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
            Curated deals updated regularly
          </p>
        </div>

        {/* Inline search */}
        <div className="glass-strong rounded-2xl flex items-center gap-3 px-4 py-3 max-w-md mx-auto mb-10">
          <Search size={16} style={{ color: "var(--text-muted)" }} />
          <input
            type="text"
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            placeholder="Filter products..."
            className="flex-1 bg-transparent text-sm outline-none"
            style={{ color: "var(--text-primary)" }}
          />
          {localSearch && (
            <button
              onClick={() => setLocalSearch("")}
              className="text-xs px-2 py-0.5 rounded-lg"
              style={{ color: "var(--text-muted)", background: "rgba(115,209,211,0.08)" }}
            >
              Clear
            </button>
          )}
        </div>

        {/* Grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="glass rounded-2xl py-20 flex flex-col items-center gap-4">
            <Package size={48} style={{ color: "var(--text-muted)" }} />
            <h3 className="font-semibold text-lg" style={{ color: "var(--text-secondary)" }}>
              No products found
            </h3>
            <p className="text-sm" style={{ color: "var(--text-muted)" }}>
              {localSearch ? `No results for "${localSearch}"` : "Products will appear here once added."}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filtered.map((p, i) => (
              <div
                key={p.id}
                className="fade-in-up"
                style={{ animationDelay: `${i * 60}ms`, opacity: 0 }}
              >
                <ProductCard product={p} />
              </div>
            ))}
          </div>
        )}

        {!loading && filtered.length > 0 && (
          <p className="text-center text-xs mt-8" style={{ color: "var(--text-muted)" }}>
            Showing {filtered.length} product{filtered.length !== 1 ? "s" : ""}
          </p>
        )}
      </div>
    </section>
  );
}
