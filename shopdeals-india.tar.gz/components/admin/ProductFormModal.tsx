"use client";
import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { X, Package } from "lucide-react";
import { productSchema } from "@/lib/security";
import type { ProductFormData, Product } from "@/types";

interface ProductFormModalProps {
  onClose: () => void;
  onSubmit: (data: ProductFormData) => Promise<void>;
  editProduct?: Product | null;
  submitting: boolean;
}

const CATEGORIES = ["Electronics", "Fashion", "Home & Kitchen", "Books", "Sports", "Beauty", "Toys", "Grocery", "Other"];

export default function ProductFormModal({ onClose, onSubmit, editProduct, submitting }: ProductFormModalProps) {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ProductFormData>({
    resolver: zodResolver(productSchema),
    defaultValues: editProduct || {},
  });

  useEffect(() => {
    if (editProduct) reset(editProduct);
    else reset({});
  }, [editProduct, reset]);

  const inputClass = "input-glass w-full px-4 py-2.5 rounded-xl text-sm";
  const labelClass = "block text-xs font-medium mb-1.5";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)" }}>
      <div className="glass-strong rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b" style={{ borderColor: "var(--glass-border)" }}>
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl btn-primary flex items-center justify-center">
              <Package size={16} />
            </div>
            <h2 className="font-semibold" style={{ color: "var(--text-primary)" }}>
              {editProduct ? "Edit Product" : "Add New Product"}
            </h2>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-white/5" style={{ color: "var(--text-muted)" }}>
            <X size={18} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Title */}
          <div className="md:col-span-2">
            <label className={labelClass} style={{ color: "var(--text-secondary)" }}>Product Title *</label>
            <input {...register("title")} type="text" placeholder="e.g. boAt Rockerz 450 Bluetooth Headphone" className={inputClass} />
            {errors.title && <p className="text-xs mt-1" style={{ color: "var(--coral)" }}>{errors.title.message}</p>}
          </div>

          {/* Description */}
          <div className="md:col-span-2">
            <label className={labelClass} style={{ color: "var(--text-secondary)" }}>Description *</label>
            <textarea {...register("description")} rows={3} placeholder="Short product description..." className={`${inputClass} resize-none`} />
            {errors.description && <p className="text-xs mt-1" style={{ color: "var(--coral)" }}>{errors.description.message}</p>}
          </div>

          {/* Image URL */}
          <div className="md:col-span-2">
            <label className={labelClass} style={{ color: "var(--text-secondary)" }}>Image URL * (Cloudinary/direct URL)</label>
            <input {...register("imageUrl")} type="url" placeholder="https://res.cloudinary.com/..." className={inputClass} />
            {errors.imageUrl && <p className="text-xs mt-1" style={{ color: "var(--coral)" }}>{errors.imageUrl.message}</p>}
          </div>

          {/* Affiliate Link */}
          <div className="md:col-span-2">
            <label className={labelClass} style={{ color: "var(--text-secondary)" }}>Affiliate Link *</label>
            <input {...register("affiliateLink")} type="url" placeholder="https://amzn.to/..." className={inputClass} />
            {errors.affiliateLink && <p className="text-xs mt-1" style={{ color: "var(--coral)" }}>{errors.affiliateLink.message}</p>}
          </div>

          {/* Platform */}
          <div>
            <label className={labelClass} style={{ color: "var(--text-secondary)" }}>Platform *</label>
            <select {...register("platform")} className={inputClass} style={{ background: "rgba(115,209,211,0.05)" }}>
              <option value="">Select...</option>
              {["Amazon", "Flipkart", "Myntra", "Other"].map((p) => (
                <option key={p} value={p} style={{ background: "#0f1a1a" }}>{p}</option>
              ))}
            </select>
            {errors.platform && <p className="text-xs mt-1" style={{ color: "var(--coral)" }}>{errors.platform.message}</p>}
          </div>

          {/* Category */}
          <div>
            <label className={labelClass} style={{ color: "var(--text-secondary)" }}>Category *</label>
            <select {...register("category")} className={inputClass} style={{ background: "rgba(115,209,211,0.05)" }}>
              <option value="">Select...</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c} style={{ background: "#0f1a1a" }}>{c}</option>
              ))}
            </select>
            {errors.category && <p className="text-xs mt-1" style={{ color: "var(--coral)" }}>{errors.category.message}</p>}
          </div>

          {/* Price */}
          <div>
            <label className={labelClass} style={{ color: "var(--text-secondary)" }}>Current Price (₹)</label>
            <input {...register("price")} type="text" placeholder="1299" className={inputClass} />
          </div>

          {/* Original Price */}
          <div>
            <label className={labelClass} style={{ color: "var(--text-secondary)" }}>Original Price (₹)</label>
            <input {...register("originalPrice")} type="text" placeholder="2499" className={inputClass} />
          </div>

          {/* Badge */}
          <div className="md:col-span-2">
            <label className={labelClass} style={{ color: "var(--text-secondary)" }}>Badge (optional)</label>
            <input {...register("badge")} type="text" placeholder="e.g. Hot Deal, New, 50% Off" className={inputClass} />
          </div>

          {/* Buttons */}
          <div className="md:col-span-2 flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl text-sm border transition-colors" style={{ borderColor: "var(--glass-border)", color: "var(--text-secondary)" }}>
              Cancel
            </button>
            <button type="submit" disabled={submitting} className="flex-1 btn-primary py-2.5 rounded-xl text-sm flex items-center justify-center gap-2 disabled:opacity-60">
              {submitting ? <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> : null}
              {editProduct ? "Save Changes" : "Add Product"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
